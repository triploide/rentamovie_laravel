<?php

namespace App\Http\Controllers\Practica;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ColeccionesController extends Controller
{
    public function test()
    {
    	return 'test';
    }


}
