<?php

namespace App\Practica;

use Illuminate\Database\Eloquent\Model;

class Collection extends Model
{
    //
}
