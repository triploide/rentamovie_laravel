<?php

namespace App\Practica;

use Illuminate\Database\Eloquent\Model;

class CollectionController extends Model
{
    //
}
