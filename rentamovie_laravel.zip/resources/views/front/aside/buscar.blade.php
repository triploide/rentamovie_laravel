<div class="block clearfix">
    <form role="search">
        <div class="form-group has-feedback">
            <input type="text" class="form-control" placeholder="Buscar">
            <i class="fa fa-search form-control-feedback"></i>
        </div>
    </form>
</div>