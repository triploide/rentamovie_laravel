<div class="block clearfix">
    <h3 class="title">Categorías</h3>
    <div class="separator-2"></div>
    <nav>
        <ul class="nav nav-pills nav-stacked">
            <li><a href="#">Acción</a></li>
            <li><a href="#">Ciencia Ficción</a></li>
            <li><a href="#">Comedia</a></li>
            <li><a href="#">Drama</a></li>
        </ul>
    </nav>
</div>