<div class="block clearfix">
    <h3 class="title">Temporada 1</h3>
    <div class="separator-2"></div>
    <nav>
        <ul class="nav nav-pills nav-stacked">
            <li><a href="#">Piloto</a></li>
            <li><a href="#">Tecnología robada</a></li>
            <li><a href="#">Muertes en serie</a></li>
            <li><a href="#">El conducto</a></li>
        </ul>
    </nav>
</div>