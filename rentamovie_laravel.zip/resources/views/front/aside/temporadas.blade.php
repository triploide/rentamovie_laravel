<div class="block clearfix">
    <h3 class="title">Temporadas</h3>
    <div class="separator-2"></div>
    <nav>
        <ul class="nav nav-pills nav-stacked">
            <li><a href="temporada.php">Temporada 1</a></li>
            <li><a href="temporada.php">Temporada 2</a></li>
            <li><a href="temporada.php">Temporada 3</a></li>
            <li><a href="temporada.php">Temporada 4</a></li>
        </ul>
    </nav>
</div>