<!-- footer top start -->
<!-- ================ -->
<div class="dark-translucent-bg footer-top animated-text" style="background-color:rgba(0,0,0,0.6);">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="call-to-action text-center">
                    <div class="row">
                        <div class="col-sm-8">
                            <h2>Recomendaciones del mes</h2>
                            <h2>Enterate de todo lo nuevo que se viene</h2>
                        </div>
                        <div class="col-sm-4">
                            <p class="mt-10"><a href="#" class="btn btn-animated radius-50 btn-lg btn-gray-transparent">Ver<i class="fa fa-arrow-right"></i></a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- footer top end -->
<!-- ================ -->