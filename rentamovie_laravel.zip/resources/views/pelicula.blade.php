<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Película</title>
</head>
<body>
	<h1>Película</h1>
	<p><?php echo($resultado); ?></p>
</body>
</html>