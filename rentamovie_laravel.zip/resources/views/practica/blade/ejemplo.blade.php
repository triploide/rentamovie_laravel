<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Ejemplo</title>
</head>
<body>
	<h1>Ejemplo</h1>
	<p>Hola <?php echo($usuario); ?></p>
</body>
</html>