<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php echo $__env->yieldContent('titulo', 'Rent a Movie'); ?></title>
</head>
<body>

	<h1>Banner</h1>
	
	<?php $__env->startSection('nav'); ?>
	<nav>
		<ul>
			<li>Nav</li>
			<li>Por</li>
			<li>Default</li>
		</ul>
	</nav>
	<?php echo $__env->yieldSection(); ?>

	<main class="container">
		<?php echo $__env->yieldContent('content'); ?>
	</main>

	<?php echo $__env->yieldContent('footer'); ?>

</body>
</html>