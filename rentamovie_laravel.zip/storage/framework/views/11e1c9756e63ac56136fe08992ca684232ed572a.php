<?php $__env->startSection('title', 'Ghostbusters'); ?>

<?php $__env->startSection('description', 'Mauris dolor sapien, malesuada at interdum ut, hendrerit eget lorem. Nunc interdum mi neque, et sollicitudin purus fermentum ut.'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><i class="fa fa-home pr-10"></i><a href="/">Home</a></li>
    <li><a href="/peliculas">Películas</a></li>
    <li class="active">Ghostbusters</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('banner'); ?>
    <div class="image-cover" style="background-image: url(content/peliculas/720x360/ghostbusters.jpg);"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- main start -->
    <!-- ================ -->
    <div class="main col-md-8">

        <!-- page-title start -->
        <!-- ================ -->
        <h1 class="page-title">Ghostbusters</h1>
        <div class="separator-2"></div>
        <!-- page-title end -->

        <div class="embed-responsive embed-responsive-16by9">
            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/7aW8oyTgA60"></iframe>
        </div>

    </div>
    <!-- main end -->

    <!-- sidebar start -->
    <!-- ================ -->
    <aside class="col-md-4 col-lg-3 col-lg-offset-1">
        <div class="sidebar">
            
            <?php echo $__env->make("front/aside/buscar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
            <?php echo $__env->make("front/aside/relacionados", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                          
        </div>
    </aside>
    <!-- sidebar end -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('calls-to-action'); ?>
    <?php echo $__env->make("front/components/calls-to-action/recomendaciones", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>