<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($actor->getNombreCompleto()); ?></title>
</head>
<body>
    <h1><?php echo e($actor->getNombreCompleto()); ?></h1>
    <p>Rating: <?php echo e($actor->rating); ?></p>
</body>
</html>