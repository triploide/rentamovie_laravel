<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Películas</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<style type="text/css">
		body {
			padding: 30px
		}
	</style>
</head>
<body>
	<h1>Películas</h1>
	<table class="table table-bordered table-striped">
		<thead>
			<tr>
				<th>Título</th>
				<th>Premios</th>
				<th>Acciones</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($movie->title); ?></td>
					<td><?php echo e($movie->awards); ?></td>
					<td><a href="/admin/peliculas/<?php echo e($movie->id); ?>/edit">Editar</a></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php echo e($movies->links()); ?>

</body>
</html>