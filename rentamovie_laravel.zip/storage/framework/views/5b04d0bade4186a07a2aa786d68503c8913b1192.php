<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Película</title>
</head>
<body>
	<h1>Película</h1>
	<ul>
		<?php $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelicula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($pelicula->titulo); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</body>
</html>