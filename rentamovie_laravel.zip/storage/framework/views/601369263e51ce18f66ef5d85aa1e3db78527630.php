<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Templates</title>
</head>
<body>
	<?php echo $__env->make('partials._titulo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	

	<ul>
		<?php $__empty_1 = true; $__currentLoopData = $errores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<li><?php echo e($error); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<li>No hay errores</li>
		<?php endif; ?>
	</ul>

</body>
</html>