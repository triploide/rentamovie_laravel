<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Actors</title>
</head>
<body>
    <h1>Actors</h1>
    <ul>
        <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="actors/<?php echo e($actor->id); ?>"><?php echo e($actor->getNombreCompleto()); ?></a> - <a href="#">Edit</a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html>