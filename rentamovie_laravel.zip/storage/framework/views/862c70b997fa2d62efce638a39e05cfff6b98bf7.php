<?php $__env->startSection('title', 'Listado de películas'); ?>

<?php $__env->startSection('description', 'Listado de películas'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><i class="fa fa-home pr-10"></i><a href="/">Home</a></li>
    <li class="active">Películas</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main col-md-8">

        <!-- page-title start -->
        <!-- ================ -->
        <h1 class="page-title">Películas - Todas</h1>
        <div class="separator-2"></div>
        <!-- page-title end -->

        

        <?php echo $__env->renderEach('front.movies._blogpost', $movies, 'movie'); ?>

        <!-- pagination start -->
        <nav>
            <ul class="pagination">
                <li><a href="#" aria-label="Previous"><i class="fa fa-angle-left"></i></a></li>
                <li class="active"><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">4</a></li>
                <li><a href="#">5</a></li>
                <li><a href="#" aria-label="Next"><i class="fa fa-angle-right"></i></a></li>
            </ul>
        </nav>
        <!-- pagination end -->

    </div>
    <!-- main end -->

    <!-- sidebar start -->
    <!-- ================ -->
    <aside class="col-md-4 col-lg-3 col-lg-offset-1">
        <div class="sidebar">
            
            <?php echo $__env->make("front/aside/buscar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
            <?php echo $__env->make("front/aside/categorias", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make("front/aside/relacionados", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                          
        </div>
    </aside>
    <!-- sidebar end -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('calls-to-action'); ?>
    <?php echo $__env->make("front/components/calls-to-action/recomendaciones", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>