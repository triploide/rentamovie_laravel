<!DOCTYPE html>
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if gt IE 9]> <html lang="en" class="ie"> <![endif]-->
<!--[if !IE]><!-->
<html lang="es">
    <!--<![endif]-->

    <head>
        <meta charset="utf-8">
        <title><?php echo $__env->yieldContent('title'); ?> - Rentamovvie</title>
        <meta name="description" content="<?php echo $__env->yieldContent('description', 'Mirá todas las películas y series desde la comodidad de tu casa. Rent a movie, compartiendo momentos.'); ?>">
        <?php echo $__env->make("front.partials.head", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('head'); ?>
    </head>
    
    <body class="no-trans front-page">

        <!-- scrollToTop -->
        <!-- ================ -->
        <div class="scrollToTop circle"><i class="icon-up-open-big"></i></div>
        
        <!-- page wrapper start -->
        <!-- ================ -->
        <div class="page-wrapper">
        
            <?php echo $__env->make("front/partials/header", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
            <!-- breadcrumb start -->
            <!-- ================ -->
            <div class="breadcrumb-container">
                <div class="container">
                    <ol class="breadcrumb">
                        <?php echo $__env->yieldContent('breadcrumb'); ?>
                    </ol>
                </div>
            </div>
            <!-- breadcrumb end -->
        
            <!-- main-container start -->
            <!-- ================ -->
            <section class="main-container">
                <?php echo $__env->yieldContent('banner'); ?>
                <div class="container">
                    <div class="row">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </section>
            <!-- main-container end -->

            <?php echo $__env->yieldContent('calls-to-action'); ?>
            
            <?php echo $__env->make("front/partials/footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
        </div>
        <!-- page-wrapper end -->

        <?php echo $__env->make("front/partials/scripts", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->yieldContent('scripts'); ?>

    </body>
</html>
